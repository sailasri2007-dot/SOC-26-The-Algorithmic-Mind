#include <iostream>
using namespace std;
#include <map>
#include <algorithm>
int main(){
    int n;
    cin>>n;
    map< long long, long long> time;
    for(int i=0;i<n;i++){
        long long a,b;
        cin>>a>>b;
        time[a]++;
        time[b]--;
    }
    long long Max = 0, sum =0;
    for (const auto& pair : time) {
        sum = sum + pair.second;
        Max = max(sum,Max);
    }
    cout<<Max<<endl;
    return 0;
}
