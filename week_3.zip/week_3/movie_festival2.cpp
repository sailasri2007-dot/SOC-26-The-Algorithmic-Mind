#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main() {
    int n, k;
    cin >> n >> k;
    vector<pair<int,int>> movies;
    for (int i = 0; i < n; i++) {
        int start, end;
        cin >> start >> end;
        movies.push_back({end, start});
    }
    sort(movies.begin(), movies.end());
    vector<int> members(k, 0);
    int count = 0;
    for (int i = 0; i < n; i++) {
    int start = movies[i].second;
    int end = movies[i].first;
    int chosen = -1;
    for (int j = 0; j < k; j++) {
        if (members[j] <= start) {
            if (chosen == -1 ||
                    members[j] > members[chosen]) {
                    chosen = j;
                }
            }
        }
    if (chosen != -1) {
        members[chosen] = end;
            count++;
        }
    }
   cout << count << endl;
   return 0;
}
