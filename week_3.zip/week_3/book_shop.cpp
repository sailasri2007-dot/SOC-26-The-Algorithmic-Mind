#include<iostream>
using namespace std;
#include<vector>
#include<algorithm>
int main(){
    int n,x;
    cin>>n>>x;
    vector<int> price;
    vector<int> pages;
    for(int i=0;i<n;i++){
        int a;
        cin>>a;
        price.push_back(a);
    }
    for(int i=0;i<n;i++){
        int a;
        cin>>a;
        pages.push_back(a);
    }
    vector<vector<int>> dp(n+1 , vector<int>(x+1, 0));
    for(int i=1;i<=n;i++){
        for( int j=0;j<=x;j++){
            int p = price[i-1];
            int page = pages[i-1];
            int pick = (j>=p ? dp[i-1][j-p] + page:0);
            int skip = dp[i-1][j];
            dp[i][j] = max(pick,skip);
        }
    }
    cout<<dp[n][x]<<endl;
    return 0;
}
