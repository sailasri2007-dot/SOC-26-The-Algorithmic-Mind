#include<iostream>
using namespace std;

const long long MOD = 1e9 + 7;
const int MAX = 1000001;
long long dp[MAX][2];

int main() {
    dp[1][0] = 1;
    dp[1][1] = 1;
    for (int i = 2; i < MAX; i++) {
        dp[i][0] = (4 * dp[i - 1][0] + dp[i - 1][1]) % MOD;
        dp[i][1] = (dp[i - 1][0] + 2 * dp[i - 1][1]) % MOD;
    }
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        cout << (dp[n][0] + dp[n][1]) % MOD << endl;
    }
    return 0;
}
