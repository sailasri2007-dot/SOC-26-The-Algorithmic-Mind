#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;

int main() {
    int n, m;
    cin >> n >> m;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    vector<vector<int>> dp(n + 1, vector<int>(m + 1, 0));
    for (int x = 1; x <= m; x++) {
        if (a[0] == 0 || a[0] == x) {
            dp[1][x] = 1;
        }
    }
    for (int i = 2; i <= n; i++) {
        for (int x = 1; x <= m; x++) {
            if (a[i - 1] != 0 && a[i - 1] != x){
                continue;
            }
            for (int prev = max(1, x - 1);prev <= min(m, x + 1);prev++) {
                dp[i][x] = (dp[i][x] + dp[i - 1][prev]) % MOD;
            }
        }
    }
    int ans = 0;
    for (int x = 1; x <= m; x++) {
        ans = (ans + dp[n][x]) % MOD;
    }
    cout << ans << endl;
    return 0;
}
