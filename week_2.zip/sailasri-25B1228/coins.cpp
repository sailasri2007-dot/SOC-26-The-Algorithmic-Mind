#include <iostream>
using namespace std;
#include <vector>
int main(){
    int n,x;
    cin>>n>>x;
    vector<int> coins;
    for(int i=0;i<n;i++){
        int a;
        cin>>a;
        coins.push_back(a);
    }
    vector<int> arr(x+1,1e9);
    arr[0]=0;
    for(int i=1;i<=x;i++){
        for(int j=0;j<n;j++){
            if(i-coins[j]>=0){
                arr[i]=min(arr[i],arr[i-coins[j]]+1);
            }
        }
    }
    if(arr[x]==1e9){
        cout<<"-1"<<endl;
    }
    else{
        cout<<arr[x]<<endl;
        return 0;
    }
}
