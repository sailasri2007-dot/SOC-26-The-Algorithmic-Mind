#include <iostream>
using namespace std;
#include <vector>
#include <algorithm>
int main(){
    int n;
    cin>>n;
    vector<pair<long long,long long>> v;
    for(int i=0; i<n;i++){
        int start,stop;
        cin>>start>>stop;
        v.push_back({stop,start});
        }
    sort(v.begin(),v.end());
    long long end=0;
    int count =0;
    for(int i=0; i<n;i++){
        if(v[i].second>=end){
            count++;
            end=v[i].first;
        }
    }
    cout<<count<<endl;
    return 0;
}

