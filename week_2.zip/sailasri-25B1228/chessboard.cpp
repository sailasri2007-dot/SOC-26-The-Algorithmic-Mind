include<iostream>
using namespace std;

string board[8];
bool col[8];
bool diag1[15];
bool diag2[15];
int ans=0;

void solve(int row){
if(row==8){
ans++;
return;
}

for(int c=0;c<8;c++){

if(board[row][c]=='*')
continue;

if(col[c]||diag1[row-c+7]||diag2[row+c])
continue;

col[c]=true;
diag1[row-c+7]=true;
diag2[row+c]=true;

solve(row+1);

col[c]=false;
diag1[row-c+7]=false;
diag2[row+c]=false;
}
}

int main(){
    
    for(int i=0;i<8;i++){
        cin>>board[i];
    }
    solve(0);
    cout<<ans<<endl;
}
