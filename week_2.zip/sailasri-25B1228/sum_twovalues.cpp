#include <iostream>
using namespace std;
#include <vector>
#include <algorithm>
int main(){
    int n;
    cin>>n;
    long long x;
    pair<long long,long long> arr[n];
    cin>>x;
    for(int i=0;i<n;i++){
        cin>>arr[i].first;
        arr[i].second=i+1;
    }
    sort(arr, arr+n);
    bool ans=false;
    int left = 0;
    int right = n-1;
    while(left<=right){
        if(left==right){
            cout<<"IMPOSSIBLE"<<endl;
            break;
        }
        else if(arr[left].first+arr[right].first==x){
            if(arr[left].second<arr[right].second){
                cout<<arr[left].second<<" "<<arr[right].second;
                break;
            }
            else{
                cout<<arr[right].second<<" "<<arr[left].second;
                break;
            }
        }
        else if(arr[left].first+arr[right].first>x){
            right--;
            continue;
        }
        else{
            left++;
            continue;
        }
    }
        return 0;
}


