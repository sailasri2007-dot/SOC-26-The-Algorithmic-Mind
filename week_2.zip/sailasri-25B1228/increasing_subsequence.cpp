#include <iostream>
using namespace std;
#include <vector>
#include <algorithm>

int main(){
    int n;
    long long x;
    cin>>n;
    vector<long long> arr(n);
    vector<long long> ans;
    for(int i=0;i<n;i++){
    cin>>arr[i];
    }
    ans.push_back(arr[0]);
    for(int i=0;i<n;i++){
        if(arr[i]>ans.back()){
            ans.push_back(arr[i]);
        }
        else{
            int ind = lower_bound(ans.begin(), ans.end(), arr[i]) - ans.begin();
            ans[ind]=arr[i];
        }
            }
    cout<<ans.size()<<endl;
    return 0;
}
        
