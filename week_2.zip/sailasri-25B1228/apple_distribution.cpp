#include <iostream>
using namespace std;
#include <cstdlib>
long long ans=1e18;
void div_apples(long long arr[] ,long long g1, long long g2, int i, int n){
    if(i==n){
        ans=min(ans,llabs(g1-g2));
        return ;
    }
    div_apples(arr,g1+arr[i],g2,i+1,n);
    div_apples(arr,g1,g2+arr[i],i+1,n);
}

int main(){
    int n,i=0;
    cin>>n;
    long long arr[n],g1=0,g2=0;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    div_apples(arr,g1,g2,i,n);
    cout<<ans<<endl;
    return 0;
}
