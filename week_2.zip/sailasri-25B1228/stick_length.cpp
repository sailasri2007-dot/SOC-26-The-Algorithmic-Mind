#include <iostream>
using namespace std;
#include <algorithm>
#include <vector>
#include <cmath>
int main(){
    int n;
    cin>>n;
    vector<long long> v;
    for(int i=0;i<n;i++){
        int a;
        cin>>a;
        v.push_back(a);
    }
    long long med,cost=0;
    sort(v.begin(),v.end());
    med = v[n/2];
    for(int i=0;i<n;i++){
        cost = cost+abs(v[i]-med);
    }
    cout<<cost<<endl;
    return 0;
}
