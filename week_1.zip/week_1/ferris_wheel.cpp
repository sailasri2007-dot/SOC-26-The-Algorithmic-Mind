#include<iostream>
using namespace std;
# include<set>
int main(){
    int n;
    long long x;
    cin>>n>>x;
    multiset<int> s;
    for(int i = 0; i < n; i++){
        long long w;
        cin >> w;
        s.insert(w);
    }
    int gondola =0;
    while(!s.empty()){
    auto heavy = --s.end();
    int h = *heavy;
    s.erase(heavy);
    auto partner = s.upper_bound(x - h);
    if(partner != s.begin()){
    partner--;
    s.erase(partner);
    }
    gondola++;
    }
    cout << gondola;
    return 0;
   }
