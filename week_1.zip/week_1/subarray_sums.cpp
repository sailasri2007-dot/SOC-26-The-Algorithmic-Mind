#include<iostream>
using namespace std;
int main(){
    int n,x;
    int count=0;
    cin>>n>>x;
    long long arr[n];
    for(int i =0; i<n; i++){
        cin>>arr[i];
    }
    for(int i=0; i<n ; i++){
        long long sum=0;
        for(int j=i;j<n ;j++){
            sum = sum+arr[j];
            if(sum==x){
                count++;
                break;
            }
            else if(sum>x){
                break;
            }
        }
    }
    cout<<count<<endl;
    return 0;
}
           

