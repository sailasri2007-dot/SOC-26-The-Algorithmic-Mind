#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    long long arr[n],num[n-1],add=0,sum =0;
    for(int i=0; i<n ; i++){
        arr[i]=i+1;
        sum = sum + arr[i];
    }
    for(int i=0; i<n-1 ; i++){
        cin>>num[i];
        add = add + num[i];
    }
    cout<<sum-add<<endl;
    return 0;
}
