#include<iostream>
using namespace std;
#include<set>
int main(){
    int n;
    cin>>n;
    long long a[n];
    for(int i=0; i<n; i++){
        cin>>a[i];
    }
    set<long long> s;
    int left=0;
    int ans =0;
    for(int right=0;right<n;right++){
        while(s.find(a[right])!=s.end()){
            s.erase(a[left]);
            left++;
        }
        s.insert(a[right]);
        ans=max(right-left+1,ans);
    }
    cout<<ans;
    return 0;
    }
    

