#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    long long arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    long long curr=arr[0];
    long long ans=arr[0];
    for(int i=1; i<n; i++){
        curr=max(arr[i],curr+arr[i]);
        ans=max(ans,curr);
    }
    cout<<ans<<endl;
}
