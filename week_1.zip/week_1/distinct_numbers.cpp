#include<iostream>
using namespace std;
int main(){
    int n,count=0;
    cin>>n;
    long long  arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    for(int i=0;i<n;i++){
        bool found = false;
        for(int j=0;j<i;j++){
            if(arr[i]==arr[j]){
                found=true;
                break;
            }
            if(found==false){
                count++;
            }
        }
    }
    cout<<count<<endl;
    return 0;
}

