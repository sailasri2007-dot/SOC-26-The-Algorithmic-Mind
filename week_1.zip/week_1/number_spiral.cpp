#include <iostream>
using namespace std;
int main(){
    long long a;
    cin>>a;
    long long num[a];
    for(int i=0; i<a ;i++){
        long long y,x,b;
        cin>>y>>x;
        if(y>x){
            if(y%2==0){
                b = y*y-x+1;
            }
            else{
                b=(y-1)*(y-1)+x;
            }
        }
        else{
            if(x%2==1){
                b = x*x-y+1;
            }
            else{
                b=(x-1)*(x-1)+y;
            }
        }
        num[i]=b;
    }
    for(int i=0; i<a ;i++){
        cout<<num[i]<<endl;
    }
    return 0;
}
