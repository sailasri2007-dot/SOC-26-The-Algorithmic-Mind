#include<iostream>
using namespace std;
#include <vector>
#include <set>
int main(){
    int n,count;
    cin>>n;
    vector<long long> v;
    for(int i=0;i<n;i++){
        int a;
        cin>>a;
        v.push_back(a);
    }
    multiset<long long> towers;
    for (int i = 0; i < n; i++) {
    auto it = towers.upper_bound(v[i]);
    if (it == towers.end()) {
    towers.insert(v[i]);
    }
    else {
    towers.erase(it);
    towers.insert(v[i]);
    }
    }
    cout << towers.size();
    return 0;
}

