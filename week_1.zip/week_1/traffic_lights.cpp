#include<iostream>
#include<set>
using namespace std;
int main(){
    int x,n,p;
    cin>>x>>n;
    set<int>s;
    multiset<int>m;
    s.insert(0);
    s.insert(x);
    m.insert(x);
    
    while(n--){
        cin>>p;
        auto r=s.upper_bound(p);
        auto l=prev(r);
        m.erase(m.find(*r-*l));
        m.insert(p-*l);
        m.insert(*r-p);
        s.insert(p);
        cout<<*m.rbegin()<<" ";
    }
    return 0;
    }

